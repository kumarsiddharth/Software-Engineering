/*I am trying to generate the following type of message
UPM: Private method is never called (UPM_UNCALLED_PRIVATE_METHOD)
This private method is never called. Although it is possible that the method will be invoked through reflection, it is more likely that the method is never used, and should be removed. */
class Circle
{
	private final double pi=Math.acos(-1.0);
	private int radius;
	private double area;
	Circle()
	{
		radius=0;
	}
	Circle(int radius)
	{
		this.radius=radius;
	}
	void input()throws IOException
	{	
		BufferedReader z=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the radius:");
		radius=Integer.parseInt(z.readLine());
	}
	void area()
	{
		area=pi*radius*radius;
		System.out.println("The area of the circle is:"+area);
	}
	private double returnArea()
	{
		return this.area;
	}
}
class Mainsclass
{
	public static void main(String args[])throws IOException
	{
		Circle circle1=new Circle(10);
		circle1.area();
	}
}
