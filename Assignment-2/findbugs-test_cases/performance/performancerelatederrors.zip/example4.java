/*I am trying to generate the following message:
 Method calls static Math class method on a constant value (UM_UNNECESSARY_MATH)
This method uses a static method from java.lang.Math on a constant value. This method's result in this case, can be determined statically, and is faster and sometimes more accurate to just use the constant.*/
import java.io.*;
class Circle
{
	private final double pi=Math.acos(-1.0);
	private int radius;
	Circle()
	{
		radius=0;
	}
	Circle(int radius)
	{
		this.radius=radius;
	}
	void input()throws IOException
	{	
		BufferedReader z=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the radius:");
		radius=Integer.parseInt(z.readLine());
	}
	void area()
	{
		double area=pi*radius*radius;
		System.out.println("The area of the circle is:"+area);
	}
}
class Mainsclass
{
	public static void main(String args[])throws IOException
	{
		Circle circle1=new Circle(10);
		circle1.area();
	}
}
