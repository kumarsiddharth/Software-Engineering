/*rF: Unread field (URF_UNREAD_FIELD)
This field is never read.  Consider removing it from the class.
UuF: Unused field (UUF_UNUSED_FIELD)
This field is never used.  Consider removing it from the class.*/
import java.io.*;
class Circle
{
	private final double pi=Math.acos(-1.0);
	private int radius;
	private int perimeter;
	Circle()
	{
		radius=0;
	}
	Circle(int radius)
	{
		this.radius=radius;
	}
	void input()throws IOException
	{	
		BufferedReader z=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the radius:");
		radius=Integer.parseInt(z.readLine());
	}
	void area()
	{
		double area=pi*radius*radius;
		System.out.println("The area of the circle is:"+area);
	}
}
class Mainsclass
{
	public static void main(String args[])throws IOException
	{
		Circle circle1=new Circle(10);
		circle1.area();
	}
}
